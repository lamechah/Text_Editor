﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2_13416793
{
    public partial class NewUserScreen : Form
    {
        public NewUserScreen()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {

            //Generate a new unique user
            //Create a new instance of Customer. 
            //Save account details to file.

            //Read file to get info
            string[] index = File.ReadAllLines("login.txt");

            string userName = textBox1.Text;
            string passWord = textBox2.Text;
            string checkPassword = textBox3.Text;
            string usertype = userType.Text;
            string firstname = textBox4.Text;
            string lastname = textBox5.Text;
            string birthDate = birthday.Text;

            //Check if username is unique and passwords match

            var UserIsValid = ValidUser();
            var PassIsValid = ValidPass();

            if ((PassIsValid == true) && (UserIsValid == true))
            {
                User user = new User(firstname, lastname, userName, passWord, usertype, birthDate);
                user.SaveToFile();

                LoginScreen login = new LoginScreen();
                this.Hide();
                login.Show();
            } 
            else
            {
               MessageBox.Show("Please try again!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Method to check if the password is valid
        public bool ValidPass()
        {
            if (textBox2.Text == textBox3.Text)
            {
                return true;
            }
            else
            {
                MessageBox.Show("Password confirmation does not match! Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        //Method to check if the user is unique 
        public bool ValidUser()

        {
            string[] index = File.ReadAllLines("login.txt");
            int i;

            for (i = 0; i < index.Length; i++)
            {
               
                string[] credential = index[i].Split(',');
                if (textBox1.Text == credential[0])

                {
                    MessageBox.Show("Username already exists!");
                    return false;
                }
            }
            return true;
        }
   
  
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void password2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lastName_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
      
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        // Cancel button takes back to login screen without storing any information
        private void Cancel_Click(object sender, EventArgs e)
        {
            LoginScreen login = new LoginScreen();
            this.Hide();
            login.Show();
        }
    }
}
