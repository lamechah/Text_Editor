﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_13416793
{
    class User
    {
        
        // Write code for Data members specific to a User
        private string username;
        private string password;
        private string userType;
        private string firstName;
        private string lastName;
        private string birthday;

        //Enable class variables to expose in public way using get and set accessors.
        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public string UserType
        {
            get { return userType; }
            set { userType = value; }
        }
        public string Birthday
        {
            get { return birthday; }
            set {birthday = value; }
        }
        // Write code for Customer Constructor.
        public User(string firstName, string lastName, string username, string password, string userType, string birthday)
        {
            //use keywrod this to qualify the fields.
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username ;
            this.password  = password ;
            this.userType  = userType ;
            this.birthday = birthday;
     
        }

        public void SaveToFile()
        {
            //Append text back to index
            //string[] content = new string[1];
            //content[0] = AccountId.ToString();
            //File.WriteAllLines(folderPath, content);

            var path = "login.txt";
            
       
            using (StreamWriter sw = File.AppendText(path))
            {
                
                sw.WriteLine(username + "," + password + "," + userType + "," + firstName + "," + lastName + "," + birthday);
                sw.Close();
            }
        }
    }
}
