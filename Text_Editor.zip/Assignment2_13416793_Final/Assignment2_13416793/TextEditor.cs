﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Assignment2_13416793
{
    public partial class TextEditor : Form
    {
        private string fileName = "";

        public TextEditor()
        {
            InitializeComponent();
        }


        // Button to change font to Italic and back
        private void toolStripButton5_Click(object sender, EventArgs e)
        {
           
            var oldFont = richTextBox1.SelectionFont;
            Font newFont;
            if (oldFont.Italic)
                newFont = new Font(oldFont, oldFont.Style & ~FontStyle.Italic);
            else
                newFont = new Font(oldFont, oldFont.Style | FontStyle.Italic);
            richTextBox1.SelectionFont = newFont;

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {

            //Close every connection
            this.Dispose();
            //Take to Login Screen again;
            LoginScreen tryAgain = new LoginScreen();
            this.Hide();
            tryAgain.Show();
        }


        // When the text editor is loaded it checks for the type of user access and returns the functions availalbe for use accordingly. 
        private void TextEditor_Load(object sender, EventArgs e)
        {
            //AddFontSize();
            toolStripLabel1.Text = "User:" + LoginScreen.GetCredentials;
            string access = LoginScreen.GetAccessType;
           // MessageBox.Show("Your access type is " + access);
         if (access == "View")
            {
                this.toolStripButton4.Enabled = false;
                this.newToolStripButton.Enabled = false;
                 this.saveToolStripButton.Enabled = false;
                 this.toolStripButton1.Enabled = false;
                 this.toolStripButton5.Enabled = false;
                 this.toolStripButton6.Enabled = false;
                 this.ComboBox1.Enabled = false;
                 this.cutToolStripButton1.Enabled = false;
                 this.copyToolStripButton1.Enabled = false;
                 this.pasteToolStripButton1.Enabled = false;
                 this.newToolStripMenuItem1.Enabled = false;
                 this.saveToolStripMenuItem1.Enabled = false;
                 this.saveAsToolStripMenuItem1.Enabled = false;
                 this.cutToolStripMenuItem1.Enabled = false;
                 this.copyToolStripMenuItem1.Enabled = false;
                 this.pasteToolStripMenuItem1.Enabled = false;
                this.richTextBox1.Enabled = false;
                MessageBox.Show("You only have view access");
            }
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        // Button to change to Bold and back
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            var oldFont = richTextBox1.SelectionFont;
            Font newFont;
            if (oldFont.Bold)
                newFont = new Font(oldFont, oldFont.Style & ~FontStyle.Bold);
            else
                newFont = new Font(oldFont, oldFont.Style | FontStyle.Bold);
            richTextBox1.SelectionFont = newFont;
        }

        // Button to change to Underline and back 

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
  
            var oldFont = richTextBox1.SelectionFont;
            Font newFont;
            if (oldFont.Underline)
                newFont = new Font(oldFont, oldFont.Style & ~FontStyle.Underline);
            else
                newFont = new Font(oldFont, oldFont.Style | FontStyle.Underline);
            richTextBox1.SelectionFont = newFont;
        }

        // Button to change Font Size and back
        private void FontChange()
        {
            float fontsize = 8;
            string fontname = richTextBox1.SelectionFont.Name;
            var fontstyle = richTextBox1.SelectionFont.Style;
            if (ComboBox1.Text != "") fontsize = float.Parse(ComboBox1.Text);
            if (fontsize == 0) fontsize = 8;
            if (richTextBox1.SelectionLength > 0)
            {
                richTextBox1.SelectionFont = new Font(fontname,fontsize, fontstyle);
            }
        }
        private void toolStripComboBox1_Click_1(object sender, EventArgs e)
           {
               FontChange();
            }

            private void toolStripButton2_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            DialogResult dr = fontDialog.ShowDialog();
            if (dr == DialogResult.OK)
            {
                string fontName;
                float fontSize;
                FontStyle fontStyle;

                fontName = fontDialog.Font.Name;
                fontSize = fontDialog.Font.Size;
                fontStyle = fontDialog.Font.Style;

                //Apply properties
                richTextBox1.Font = fontDialog.Font;
            }
      
        }

        private void openToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            TextEditor newfile = new TextEditor();
            this.Hide();
            newfile.Show();
        }

        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            TextEditor newfile = new TextEditor();
            this.Hide();
            newfile.Show();
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        //Open File Method user Dialog Box
        public void OpenFile()
        {
            try
            {
                OpenFileDialog openFile = new OpenFileDialog();
                openFile.Title = "Open a Rich Text File";
                openFile.Filter = "Rich Text File (*.rtf)|";
                DialogResult dr = openFile.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    string filename = openFile.FileName;
                    MessageBox.Show("File name open is:" + filename);

                    //Read and open file 
                    var sr = new StreamReader(openFile.FileName);
                  
                    richTextBox1.LoadFile(filename);
                    sr.Close();
                    this.fileName = filename;
                 
                }
            }
            catch
            {
              MessageBox.Show("Error when opening file!\nOnly .rtf files can be opened.\nPlease select another file");
              OpenFile();
            }
        }

        //Method to save file - only calls the Dialog Box if the filename does not exist
        public void SaveFile()
        {
            if (fileName == "")
            {
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.Title = "Save a Rich Text File";
                saveFile.Filter = "Rich Text File (*.rtf)|";
                DialogResult dr1 = saveFile.ShowDialog();
                if (dr1 == DialogResult.OK)

                {
                    string filename = saveFile.FileName;
                    //StreamWriter sw = new StreamWriter(path);
                    //sw.WriteLine(richTextBox1.Text);
                    //sw.Close();
                    richTextBox1.SaveFile(filename);
                    this.fileName = filename;
                }
            } else
            {
                richTextBox1.SaveFile(this.fileName);
            }
            
        }

        //Method to SaveAsFile
        public void SaveAsFile()
        {

            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Title = "Save a Rich Text File";
            saveFile.Filter = "Rich Text File (*.rtf)|";
            DialogResult dr1 = saveFile.ShowDialog();
            if (dr1 == DialogResult.OK)

            {
                string filename = saveFile.FileName;
                richTextBox1.SaveFile(filename);
            }
            
        }

        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void cutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Cut();
        }
        public void Cut()
        {
            if (richTextBox1.SelectedText != "")
                // Cut the selected text in the control and paste it into the Clipboard.
                richTextBox1.Cut();
        }
        public void Copy()
        {
            if (richTextBox1.SelectedText != "")
                // Cut the selected text in the control and paste it into the Clipboard.
                richTextBox1.Copy();
        }
        public void Paste()
        {

            // Determine if there is any text in the Clipboard to paste into the text box.
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                // Determine if any text is selected in the text box.
                if (richTextBox1.SelectionLength > 0)
                {
                    // Ask user if they want to paste over currently selected text.
                    if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example", MessageBoxButtons.YesNo) == DialogResult.No)
                        // Move selection to the point after the current selection and paste.
                        richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                }
                // Paste current text in Clipboard into text box.
                richTextBox1.Paste();

                if (richTextBox1.SelectedText != "")
                    // Cut the selected text in the control and paste it into the Clipboard.
                    richTextBox1.Paste();
            }
        }

        private void cutToolStripButton1_Click(object sender, EventArgs e)
        {
            Cut();
        }

        private void copyToolStripButton1_Click(object sender, EventArgs e)
        {
            Copy();
        }

        private void copyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Copy();
        }

        private void pasteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Paste();
        }

        private void pasteToolStripButton1_Click(object sender, EventArgs e)
        {
            Paste();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

            SaveAsFile();
        }

        private void saveAsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveAsFile();
        }

        private void FontChange(object sender, EventArgs e)
        {
            FontChange();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AboutBox1 about = new AboutBox1();
            about.Show();
        }

        private void helpToolStripButton_Click(object sender, EventArgs e)
        {
            AboutBox1 about = new AboutBox1();
            about.Show();
        }
    }
}




        
    


