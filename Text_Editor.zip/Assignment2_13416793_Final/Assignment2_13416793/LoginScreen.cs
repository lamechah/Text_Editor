﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2_13416793
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        //Accesors to get and set the credentials and the access type 
         public static string GetCredentials
         {
            get; set;
        }
        public static string GetAccessType
        {
            get; set;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        // Login button - credentials are validated before log in is confirmed.
        private void button2_Click(object sender, EventArgs e)
        {
            // Method to check credetianls is called here! 
            var isValid = ValidateCredentials();
            if (isValid)
            {
                MessageBox.Show("Valid Credentials...!");
                // Take to the Text Editor;
                string cred = Username.Text;
                TextEditor textEditor = new TextEditor();
                textEditor.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invaild Credentials - Try again");
                //Take to Login Screen again;
                LoginScreen tryAgain = new LoginScreen();
                this.Hide();
                tryAgain.Show();
            }
        }

        //Method that returts true or false to check credentials against login.txt file.
        //Split each line using "," as delimiter and print values entered.
        public bool ValidateCredentials()
        {
            FileStream F = new FileStream("login.txt", FileMode.Open, FileAccess.Read,
            FileShare.Read);
            int i;
            GetCredentials = Username.Text;
            //Read file to get info
            string[] LoginCredentials = File.ReadAllLines("login.txt");
            for (i = 0; i < LoginCredentials.Length; i++)
            {
                
                string[] credential = LoginCredentials[i].Split(',');
                //Check if input matches
                if (Username.Text == credential[0] && Password.Text == credential[1])
                {
                    //Stores the accesstype information in a string;
                    string accesstype = credential[2];
                    GetAccessType = accesstype;
                    F.Close();
                    return true;
                }
            }
            F.Close();
            return false;
        }
       

        // Button that takes to new user section
        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("This was clicked");
            NewUserScreen newuser = new NewUserScreen();
            this.Hide();
            newuser.Show();
        }

        //Button that closes the application
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}


